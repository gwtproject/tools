package org.epistem.servlet;

import java.io.PrintWriter;
			
/**
 * PrintWriter that loses all its output
 */
public class NullPrintWriter extends PrintWriter 
{
	public NullPrintWriter() 
	{
		super( new NullServletOutputStream() );
	}
}
