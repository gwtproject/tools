package org.epistem.servlet;

import java.io.IOException;

import javax.servlet.ServletOutputStream;
	
/**
 * ServletOutputStream that loses all its output
 */
public class NullServletOutputStream extends ServletOutputStream 
{
	public void write( int b ) throws IOException { /* throw byte away */ }
	public void write( byte[] b, int off, int len ) throws IOException { /* throw bytes away */ }
	public void write( byte[] b ) throws IOException { /* throw bytes away */ }		
}
