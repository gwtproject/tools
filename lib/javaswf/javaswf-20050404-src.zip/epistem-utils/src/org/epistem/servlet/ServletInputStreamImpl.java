package org.epistem.servlet;

import java.io.*;
import javax.servlet.*;

/**
 * An implementation of ServletInputStream that wraps a plain InputStream
 */
public class ServletInputStreamImpl extends ServletInputStream 
{
    private InputStream in;
    
    public ServletInputStreamImpl( InputStream in ) {
        this.in = in;
    }

	/**
	 *  @see java.io.InputStream#read()
	 */
    public int read() throws IOException {
        return in.read();
    }
}
