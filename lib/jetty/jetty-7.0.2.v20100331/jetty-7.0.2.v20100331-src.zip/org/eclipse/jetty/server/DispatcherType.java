
package org.eclipse.jetty.server;

public enum DispatcherType 
{
    FORWARD,
    INCLUDE,
    REQUEST,
    ASYNC,
    ERROR
}
